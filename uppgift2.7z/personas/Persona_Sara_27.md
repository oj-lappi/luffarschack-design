# Persona: Sara Nördén

Sekundär

## Bakgrund

 - 27, Kvinna
 - Bor i Helsingfors
 - Diplomingenjör i Datateknik från Aalto Universitet
 - Singel 
 - Expert-användare, använder inte javascript i browsern
 - Browsar webben med w3m

## Motivationer

 - Utmana sig själv
 - Forska i hur spelet fungerar

## Vanor

 - Använder datorn dagligen
 - Gillar att sätta sig in i något för längre stunder

## Hobbyer

 - Datorer
 - Spel
 - Joggning

## Gillar

 - Belgiska öler
 - Böcker
 - Sci-fi

## Gillar inte

 - Javascript
 - Microsoft
 - Enkla spel

Sara Nördén är en Helsingforsisk teknolog som vill utmana sig själv så mycket som möjligt. Läser mycket stora böcker och är intresserad av system och strategi.

Hon bor ensam i en tvåa, jobbar på ett teknologiföretag som sysadmin och har ibland långa pauser på jobbet då hon kan spela lite luffarschack om inget händer just då. Hon arbetar också mycket hemifrån.

Om hon spelar luffarschack vill hon utmanas så hårt som möjligt. Hon vill spela varianter med större och större spelplan - inklusive oändligt stora - och försöka utveckla en teoretisk modell för en optimal strategi.

Hon använder en Lenovo X230 som laptop och en självbyggd dator hemifrån, plus ett antal virtuella servrar som hon hyr ut till personlig användning. Hon kör FreeBSD och i3wm. Använder inte mus.

Hon är van med att installera och prova nya program, och utforskar alla sätt att använda program när hon ser dem. 

Hon gillar goda öler och indisk mat.


Scenarier
=========

Konfigurera
-----------

Sara kommer att prova många olika konfigurationer och vill antagligen ändra på dem lite åt gången. För henne är det viktigt att det går att tabba mellan input-kontroller och styra inställningarna via keyboard.

Hon kommer inte att använda default-konfigurationerna, men vill kunna köra samma speltyp på nytt. Hon vill alltså att konfigurationen sparas.

Gå med i spel
-------------

Sara vill gärna spela mot andra duktiga spelare för att utmana sig själv. Om det inte finns duktiga spelare kommer hon att bli uttråkad och spela mot ett AI. Men AIn kommer inte att intressera henne länge om hon hittar en strategi för att vinna den. => Matchmaking baserad på typ ELO är alltså viktigt för Sara.

Spela
-----

Sara kommer att spela både fokuserat - om hon är inne i spelet - och med sidoögat - om hon tex. vaktar en uppdatering på jobbet. Spelet borde vara både lätt att fokusera på, enkelt att se statusen av och inte väcka för mycket uppmärksamhet på hennes skärm.
